// In this file we declare all the constants which we are using in action as well as reducer
export const POSTS_LIST = 'posts_list';
export const SET_POSTS_DATA = 'set_posts_data';
export const ERROR = 'error'